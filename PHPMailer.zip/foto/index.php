<?php 
echo "<script>window.alert('upload berhasil'); window.location=('../index.php')</script>";
  ?>
tes