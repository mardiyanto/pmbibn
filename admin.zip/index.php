<?php 
  date_default_timezone_set('Asia/Jakarta');
  ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>INSTITU BAKTI NUSANTARA LAMPUNG</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="tema/img/logoibn.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="tema/lib/animate/animate.min.css" rel="stylesheet">
    <link href="tema/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="tema/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="tema/css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="index.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <img class="img-fluid" src="tema/img/logo-tema.png" alt="">
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="index.php" class="nav-item nav-link active">Beranda</a>
                <a href="tentang.php" class="nav-item nav-link">Tentang</a>
                <a href="jurusan.php" class="nav-item nav-link">Jurusan</a>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Akademik</a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="https://daftar.ibnus.ac.id" target="_blank" class="dropdown-item">PMB</a>
                        <a href="http://103.126.172.193:82/index.php/login" target="_blank" class="dropdown-item">Siakad</a>
                        <a href="#" class="dropdown-item">Dosen Kami</a>
                        <a href="#" class="dropdown-item">Testimonial</a>
                    </div>
                </div>
                <a href="biaya.php" class="nav-item nav-link">Biaya</a>
                <a href="hubungi.php" class="nav-item nav-link">Hubungi Kami</a>
            </div>
            <a href="https://daftar.ibnus.ac.id" target="_blank" class="btn btn-primary py-4 px-lg-5 d-none d-lg-block">Join Now<i class="fa fa-arrow-right ms-3"></i></a>
        </div>
    </nav>
    <!-- Navbar End -->
    <!-- Carousel Start -->
<?php include "slide.php";?>
    <!-- Carousel End -->


    <!-- Service Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-graduation-cap text-primary mb-4"></i>
                            <h5 class="mb-3">Skilled Instructors</h5>
                            <p>Kampus Ibn menawarkan lebih dari sekadar pendidikan. Di sini, Anda akan belajar dari para ahli di bidangnya, memperoleh wawasan yang mendalam, dan merasakan pengajaran yang dipimpin oleh pengalaman praktis dan keahlian yang teruji.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-globe text-primary mb-4"></i>
                            <h5 class="mb-3">Online Classes</h5>
                            <p>Kampus Ibn menyambut era baru pendidikan yang menghadirkan kemudahan akses melalui kelas online. Kami memahami kebutuhan akan pembelajaran yang fleksibel tanpa mengorbankan kualitas.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-home text-primary mb-4"></i>
                            <h5 class="mb-3">Branding Design</h5>
                            <p>Kampus kami bukan hanya tentang pembelajaran, tapi juga tentang menciptakan identitas. Di sini, kami mengasah bakat dan keterampilan dalam Branding Design untuk menciptakan merek yang kuat dan ikonik</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-book-open text-primary mb-4"></i>
                            <h5 class="mb-3">Digital Martketing</h5>
                            <p>Jadilah arsitek perubahan di era digital! Jurusan Digital Marketing di kampus kami adalah jembatan antara kreativitas dan teknologi, mempersiapkanmu menjadi ahli strategi pemasaran yang handal dalam ranah digital.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Service End -->


    <!-- About Start -->
    <section id="tentang">
    <div class="container-xxl py-5" >
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="img-fluid position-absolute w-100 h-100" src="tema/img/logoibn.png" alt="" style="object-fit: cover;">
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <h6 class="section-title bg-white text-start text-primary pe-3">About Us</h6>
                    <h1 class="mb-4">Selamat Datang Di Website Resmi IBN Lampung</h1>
                    <p class="mb-4">Kami bukan yang terbaik, Tetapi Kami akan menjadi yang paling baik</p>
                    <p class="mb-4">Kampus Ibn adalah sebuah lembaga pendidikan tinggi yang berkomitmen untuk menyediakan pendidikan berkualitas dalam bidang komputer dan bisnis. Dengan fokus pada pengembangan teknologi dan pemahaman mendalam tentang aspek bisnis, Kampus Ibn menawarkan berbagai jurusan:</p>
                    <div class="row gy-2 gx-4 mb-4">
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Jurusan Sistem Informasi</p>
                            <p class="mb-0"><i class="far fa-hand-point-right text-primary me-2"></i>Memadukan teknologi informasi dan bisnis untuk menghasilkan profesional TI yang memiliki pemahaman mendalam tentang teknologi dan mampu mengelola informasi secara efektif.</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Jurusan Manajemen Informatika</p>
                            <p class="mb-0"><i class="far fa-hand-point-right text-primary me-2"></i>Fokus pada pengelolaan sistem informasi di berbagai industri, menghasilkan lulusan yang mampu mengintegrasikan teknologi informasi dengan strategi bisnis. </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Jurusan Bisnis Digita</p>
                            <p class="mb-0"><i class="far fa-hand-point-right text-primary me-2"></i> Menggabungkan aspek bisnis dan teknologi digital, melatih mahasiswa untuk menghadapi era digital dengan keterampilan yang relevan dalam pemasaran online, analisis data, dan pengembangan strategi digital.</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Jurusan Manajemen</p>
                            <p class="mb-0"><i class="far fa-hand-point-right text-primary me-2"></i>Mempersiapkan mahasiswa dengan pemahaman yang luas tentang manajemen, memfokuskan pada kepemimpinan, pengelolaan sumber daya, dan strategi bisnis. </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Jurusan Teknik Otomotif</p>
                            <p class="mb-0"><i class="far fa-hand-point-right text-primary me-2"></i>Menyediakan pengetahuan mendalam tentang teknologi otomotif, termasuk desain, perbaikan, dan pemeliharaan kendaraan. </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Jurusan Teknik Elektro</p>
                            <p class="mb-0"><i class="far fa-hand-point-right text-primary me-2"></i>Mengajarkan tentang teknologi listrik, elektronik, dan komputer, membekali mahasiswa dengan keterampilan dalam merancang, mengembangkan, dan memelihara sistem listrik dan elektronik.</p>
                        </div>
                    </div>
                    <a class="btn btn-primary py-3 px-5 mt-2" href="biaya.php">Read More</a>
                </div>
            </div>
        </div>
    </div> 
</section>
    <!-- About End -->

    <?php include "jur.php" ?>
   


    <!-- Team Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Instructors</h6>
                <h1 class="mb-5">Expert Instructors</h1>
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="tema/img/miswan.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">MISWAN GUMANTI, M.B.A</h5>
                            <small>Bisnis Digital</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="tema/img/dimah.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">MUKODIMAH,M.T.I</h5>
                            <small>DATA MINING</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="tema/img/suyono.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">SUYONO, M.T.I</h5>
                            <small>WEB DESAIN</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="tema/img/trisna.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">TRINAWATI, M.Pd</h5>
                            <small>MANAJEMEN</small>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <!-- Team End -->


    <!-- Testimonial Start -->
    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="text-center">
                <h6 class="section-title bg-white text-center text-primary px-3">Testimonial</h6>
                <h1 class="mb-5">Mahasiswa Kami</h1>
            </div>
            <div class="owl-carousel testimonial-carousel position-relative">
                <div class="testimonial-item text-center">
                    <img class="border rounded-circle p-2 mx-auto mb-3" src="tema/img/ade.jpg" style="width: 80px; height: 80px;">
                    <h5 class="mb-0">Ade Irfan,S.Kom</h5>
                    <p>Profession</p>
                    <div class="testimonial-text bg-light text-center p-4">
                    <p class="mb-0">Kampus Ibn telah memberikan fondasi yang kuat bagi perjalanan karier saya. Pengalaman belajar yang berfokus pada praktek langsung membantu saya mengembangkan keterampilan yang diperlukan di industri saat ini. Saya sangat berterima kasih atas dukungan instruktur yang luar biasa dan fasilitas modern yang diberikan oleh Kampus Ibn.</p>
                    </div>
                </div>
                <div class="testimonial-item text-center">
                    <img class="border rounded-circle p-2 mx-auto mb-3" src="tema/img/idris.jpg" style="width: 80px; height: 80px;">
                    <h5 class="mb-0">M.Idris,S.Kom</h5>
                    <p>Profession</p>
                    <div class="testimonial-text bg-light text-center p-4">
                    <p class="mb-0">Saya merasa sangat beruntung dapat belajar di Kampus Ibn. Lingkungan pembelajaran yang mendukung dan inklusif membuat saya merasa dihargai sebagai individu. Program-program inovatif dan kesempatan untuk terlibat dalam proyek-proyek nyata memberikan wawasan mendalam dalam studi saya.</p>
                    </div>
                </div>
                <div class="testimonial-item text-center">
                    <img class="border rounded-circle p-2 mx-auto mb-3" src="tema/img/novi1.jpg" style="width: 80px; height: 80px;">
                    <h5 class="mb-0">Vivi Novita Destiana, S.Kom<</h5>
                    <p>Profession</p>
                    <div class="testimonial-text bg-light text-center p-4">
                    <p class="mb-0">Pembelajaran di Kampus Ibn membuka mata saya terhadap dunia bisnis digital yang dinamis. Saya mendapat kesempatan untuk mengembangkan ide-ide kreatif dan melihatnya tumbuh menjadi strategi bisnis yang nyata. Ini adalah pengalaman belajar yang luar biasa dan relevan dengan zaman.</p>
                    </div>
                </div>
                <div class="testimonial-item text-center">
                    <img class="border rounded-circle p-2 mx-auto mb-3" src="tema/img/novi.jpg" style="width: 80px; height: 80px;">
                    <h5 class="mb-0">Novita Mulya Sari, Amd.Kom</h5>
                    <p>Profession</p>
                    <div class="testimonial-text bg-light text-center p-4">
                    <p class="mb-0">Kampus Ibn telah memberikan landasan kokoh bagi karier saya di dunia teknologi. Pembelajaran yang terkini dan dukungan instruktur yang berpengalaman telah membantu saya meniti jalan di industri ini. Saya merasa beruntung menjadi bagian dari komunitas alumni yang selalu mendukung satu sama lain.</p>
                    </div>
                </div>
                <div class="testimonial-item text-center">
                    <img class="border rounded-circle p-2 mx-auto mb-3" src="tema/img/ayu.jpg" style="width: 80px; height: 80px;">
                    <h5 class="mb-0">Ayu Sekar Sari, S.Kom</h5>
                    <p>Profession</p>
                    <div class="testimonial-text bg-light text-center p-4">
                    <p class="mb-0">Saya sangat terkesan dengan fokus Kampus Ibn pada integrasi teknologi informasi dan manajemen. Dengan pengalaman langsung dalam mengelola sistem informasi, saya merasa siap untuk menghadapi tantangan dalam mengelola bisnis masa depan yang berbasis teknologi.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->
        

    <!-- Footer Start -->
    <?php include "bawah.php" ?>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="tema/lib/wow/wow.min.js"></script>
    <script src="tema/lib/easing/easing.min.js"></script>
    <script src="tema/lib/waypoints/waypoints.min.js"></script>
    <script src="tema/lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="tema/js/main.js"></script>
</body>
